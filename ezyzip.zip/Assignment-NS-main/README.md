# Assignment-NS
# Problem 1 : SuperNatural - Mahabharata
Trained a multi-label neural net to solve the given problem using the dataset of 5 images provided. Got an accuracy of 80% as the size of the dataset was small. Also predicted on an unseen image and the results snip have already been uploaded.
- Problem 1.ipynb : Code
- Training: Images (dataset) used to train
- Model summary and prediction : Snips of the model summary and predicted label of an unseen image.
